﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectManager : MonoBehaviour
{
    public static ProjectManager instance;

    [Header("Essentials")]
    public GameObject opening;
    public GameObject InGame;
    public GameObject ending;
    public GameObject menuUI;
    public static bool isSkipBtnClicked = false;

    // Start is called before the first frame update
    Coroutine coroutine;
    void Awake()
    {
        if(instance == null)
            instance = this;

        opening.SetActive(false);
        InGame.SetActive(false);
        ending.SetActive(false);
        menuUI.SetActive(false);
        
        coroutine = StartCoroutine(Sequence());
    }

    int i = 0;
    private void Update() {
        if(Input.GetKeyDown(KeyCode.Space)){
            isSkipBtnClicked = true;
            print(i++);
        }
    }

    IEnumerator Sequence()
    {
        opening.SetActive(true);
                
        print("Set Active Opening");
        yield return new WaitUntil(() => opening.activeSelf == false);

        InGame.SetActive(true);
        print("Set Active InGame");
        yield return new WaitUntil(() => InGame.activeSelf == false);

        ending.SetActive(true);
        print("Set Active Ending");

    }

}
