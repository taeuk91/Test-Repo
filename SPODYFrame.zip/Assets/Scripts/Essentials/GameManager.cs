﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private void OnEnable()
    {
        InitializeGame();
    }
    void InitializeGame()
    {
        print("게임 시작!");
    }
}
