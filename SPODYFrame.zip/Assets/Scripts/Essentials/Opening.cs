﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Opening : MonoBehaviour
{
    public GameObject openingCharacter;
    public GameObject countDown;

    // Start is called before the first frame update
    void Start()
    {
        openingCharacter.SetActive(false);
        countDown.SetActive(false);

        StartCoroutine(Sequence());
    }

    IEnumerator Sequence()
    {
        openingCharacter.SetActive(true);    

        yield return new WaitUntil(() => !openingCharacter.activeSelf ||
         ProjectManager.isSkipBtnClicked);

        ProjectManager.isSkipBtnClicked = false;
        // 페이드 인 아웃
        openingCharacter.SetActive(false);

        countDown.SetActive(true);

        yield return new WaitUntil(() => !countDown.activeSelf);

        yield return new WaitForSeconds(1);

        this.gameObject.SetActive(false);
    }
}
