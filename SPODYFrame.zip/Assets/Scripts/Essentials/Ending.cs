﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ending : MonoBehaviour
{
    public GameObject endingCharacter;
    public GameObject menuUI;
    // Start is called before the first frame update
    void Start()
    {
        endingCharacter.SetActive(false);
        menuUI.SetActive(false);

        StartCoroutine(Sequence());
    }

    IEnumerator Sequence()
    {
        endingCharacter.SetActive(true);

        yield return new WaitUntil(() => ProjectManager.isSkipBtnClicked);

        ProjectManager.isSkipBtnClicked = false;

        menuUI.SetActive(true);

        // 페이드 인 아웃
        print("게임 종료");
    }
}
