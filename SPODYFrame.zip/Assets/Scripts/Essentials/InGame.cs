﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InGame : MonoBehaviour
{
    public GameObject introCharacter;
    public GameObject gameManager;
    
    // Start is called before the first frame update
    void Start()
    {
        introCharacter.SetActive(false);
        gameManager.SetActive(false);

        StartCoroutine(Sequence());
    }

    IEnumerator Sequence()
    {
        introCharacter.SetActive(true);
        print("IntroCharacter Taking");

        yield return new WaitUntil(() => !introCharacter.activeSelf
        || ProjectManager.isSkipBtnClicked);

        ProjectManager.isSkipBtnClicked = false;

        // 페이드 인 아웃
        introCharacter.SetActive(false);

        gameManager.SetActive(true);

        yield return new WaitUntil(() => !gameManager.activeSelf
        || ProjectManager.isSkipBtnClicked);

        ProjectManager.isSkipBtnClicked = false;

        // 페이드 인 아웃
        gameManager.SetActive(false);

        yield return new WaitForSeconds(1);

        this.gameObject.SetActive(false);

    }

}
